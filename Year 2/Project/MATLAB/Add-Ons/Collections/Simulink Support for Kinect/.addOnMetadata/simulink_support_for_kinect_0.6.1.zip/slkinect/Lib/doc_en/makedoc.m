opts.evalCode=false;
opts.outputDir='.';
publish('slnid_imaq.m',opts);
publish('slnid_image.m',opts);
publish('slnid_depth.m',opts);
publish('slnid_motion.m',opts);
publish('slnid_skeleton.m',opts);
publish('slnid_ir.m',opts);
