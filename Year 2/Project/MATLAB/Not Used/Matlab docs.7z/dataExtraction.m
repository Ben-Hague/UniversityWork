function data = dataExtraction(metaDataIn, gestureType)
    metaDataToExtractFrom = metaDataIn; %Change to other gesture recording
    data = zeros(1,20,3,90);
    data(1,:,:,:) = gestureType;
    for i = 1:90
        frameData = metaDataToExtractFrom(i).JointWorldCoordinates(:,:,1);
        for y = 1:20
            for x = 1:3
                data(y,x,i,1) = frameData(y,x);
            end
        end
    end
end
